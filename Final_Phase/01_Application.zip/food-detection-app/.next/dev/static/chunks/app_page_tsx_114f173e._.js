(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_f9c90dcc._.js",
  "static/chunks/node_modules_next_5b3f4365._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_onnxruntime-web_dist_a8cf34eb._.js",
  "static/chunks/node_modules_motion-dom_dist_es_da948acf._.js",
  "static/chunks/node_modules_framer-motion_dist_es_fdd5ade6._.js",
  "static/chunks/node_modules_6b9e63a5._.js"
],
    source: "dynamic"
});
